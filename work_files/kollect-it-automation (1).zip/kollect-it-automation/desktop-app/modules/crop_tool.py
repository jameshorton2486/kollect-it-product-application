#!/usr/bin/env python3
"""
Crop Tool Module
Interactive image cropping dialog with various features.
"""

from pathlib import Path
from typing import Optional, Tuple

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QComboBox, QWidget, QRubberBand, QSizePolicy,
    QScrollArea, QCheckBox, QSpinBox, QGroupBox, QFormLayout
)
from PyQt5.QtCore import Qt, QRect, QPoint, QSize
from PyQt5.QtGui import QPixmap, QImage, QPainter, QPen, QColor, QTransform

from PIL import Image


class CropLabel(QLabel):
    """
    Custom QLabel with crop region selection.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        
        self.rubber_band = None
        self.origin = QPoint()
        self.crop_rect = QRect()
        self.scale_factor = 1.0
        self.original_size = QSize()
        
        # Grid overlay
        self.show_grid = True
        self.grid_type = "rule_of_thirds"  # or "grid"
        
    def set_image(self, pixmap: QPixmap, scale: float = 1.0):
        """Set the image and scale factor."""
        self.scale_factor = scale
        self.original_size = pixmap.size()
        
        if scale != 1.0:
            scaled = pixmap.scaled(
                pixmap.size() * scale,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.setPixmap(scaled)
        else:
            self.setPixmap(pixmap)
        
        self.adjustSize()
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.origin = event.pos()
            
            if not self.rubber_band:
                self.rubber_band = QRubberBand(QRubberBand.Rectangle, self)
            
            self.rubber_band.setGeometry(QRect(self.origin, QSize()))
            self.rubber_band.show()
    
    def mouseMoveEvent(self, event):
        if self.rubber_band and self.rubber_band.isVisible():
            self.rubber_band.setGeometry(
                QRect(self.origin, event.pos()).normalized()
            )
    
    def mouseReleaseEvent(self, event):
        if self.rubber_band and event.button() == Qt.LeftButton:
            self.crop_rect = self.rubber_band.geometry()
            self.update()
    
    def paintEvent(self, event):
        super().paintEvent(event)
        
        if self.show_grid and self.pixmap():
            painter = QPainter(self)
            painter.setPen(QPen(QColor(255, 255, 255, 100), 1, Qt.DashLine))
            
            rect = self.crop_rect if self.crop_rect.isValid() else self.rect()
            
            if self.grid_type == "rule_of_thirds":
                # Rule of thirds lines
                third_w = rect.width() // 3
                third_h = rect.height() // 3
                
                for i in range(1, 3):
                    # Vertical lines
                    x = rect.x() + third_w * i
                    painter.drawLine(x, rect.y(), x, rect.y() + rect.height())
                    
                    # Horizontal lines
                    y = rect.y() + third_h * i
                    painter.drawLine(rect.x(), y, rect.x() + rect.width(), y)
            
            elif self.grid_type == "grid":
                # 5x5 grid
                cell_w = rect.width() // 5
                cell_h = rect.height() // 5
                
                for i in range(1, 5):
                    x = rect.x() + cell_w * i
                    y = rect.y() + cell_h * i
                    painter.drawLine(x, rect.y(), x, rect.y() + rect.height())
                    painter.drawLine(rect.x(), y, rect.x() + rect.width(), y)
            
            painter.end()
    
    def get_crop_rect_original(self) -> QRect:
        """Get crop rectangle in original image coordinates."""
        if not self.crop_rect.isValid():
            return QRect()
        
        return QRect(
            int(self.crop_rect.x() / self.scale_factor),
            int(self.crop_rect.y() / self.scale_factor),
            int(self.crop_rect.width() / self.scale_factor),
            int(self.crop_rect.height() / self.scale_factor)
        )
    
    def reset_selection(self):
        """Clear the crop selection."""
        if self.rubber_band:
            self.rubber_band.hide()
        self.crop_rect = QRect()
        self.update()


class CropDialog(QDialog):
    """
    Image cropping dialog with rotation and aspect ratio controls.
    """
    
    def __init__(self, image_path: str, parent=None):
        super().__init__(parent)
        self.image_path = Path(image_path)
        self.original_image = None
        self.current_rotation = 0
        self.output_path = None
        
        self.setWindowTitle(f"Crop Image - {self.image_path.name}")
        self.setMinimumSize(900, 700)
        
        self.setup_ui()
        self.load_image()
    
    def setup_ui(self):
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Toolbar area
        toolbar = QHBoxLayout()
        
        # Rotation controls
        rotate_group = QGroupBox("Rotation")
        rotate_layout = QHBoxLayout(rotate_group)
        
        self.rotate_left_btn = QPushButton("↶ 90°")
        self.rotate_left_btn.clicked.connect(lambda: self.rotate(-90))
        rotate_layout.addWidget(self.rotate_left_btn)
        
        self.rotate_right_btn = QPushButton("↷ 90°")
        self.rotate_right_btn.clicked.connect(lambda: self.rotate(90))
        rotate_layout.addWidget(self.rotate_right_btn)
        
        self.flip_h_btn = QPushButton("⇆ Flip H")
        self.flip_h_btn.clicked.connect(lambda: self.flip("horizontal"))
        rotate_layout.addWidget(self.flip_h_btn)
        
        self.flip_v_btn = QPushButton("⇅ Flip V")
        self.flip_v_btn.clicked.connect(lambda: self.flip("vertical"))
        rotate_layout.addWidget(self.flip_v_btn)
        
        toolbar.addWidget(rotate_group)
        
        # Aspect ratio controls
        aspect_group = QGroupBox("Aspect Ratio")
        aspect_layout = QHBoxLayout(aspect_group)
        
        self.aspect_combo = QComboBox()
        self.aspect_combo.addItems([
            "Free",
            "1:1 Square",
            "4:3",
            "3:4",
            "16:9",
            "9:16",
            "3:2",
            "2:3"
        ])
        self.aspect_combo.currentIndexChanged.connect(self.on_aspect_changed)
        aspect_layout.addWidget(self.aspect_combo)
        
        toolbar.addWidget(aspect_group)
        
        # Grid controls
        grid_group = QGroupBox("Grid Overlay")
        grid_layout = QHBoxLayout(grid_group)
        
        self.grid_check = QCheckBox("Show Grid")
        self.grid_check.setChecked(True)
        self.grid_check.stateChanged.connect(self.toggle_grid)
        grid_layout.addWidget(self.grid_check)
        
        self.grid_combo = QComboBox()
        self.grid_combo.addItems(["Rule of Thirds", "Grid 5x5"])
        self.grid_combo.currentIndexChanged.connect(self.change_grid_type)
        grid_layout.addWidget(self.grid_combo)
        
        toolbar.addWidget(grid_group)
        toolbar.addStretch()
        
        layout.addLayout(toolbar)
        
        # Image area with scroll
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setAlignment(Qt.AlignCenter)
        
        self.crop_label = CropLabel()
        self.crop_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        scroll.setWidget(self.crop_label)
        
        layout.addWidget(scroll, stretch=1)
        
        # Zoom controls
        zoom_layout = QHBoxLayout()
        
        zoom_layout.addWidget(QLabel("Zoom:"))
        
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(25, 200)
        self.zoom_slider.setValue(100)
        self.zoom_slider.valueChanged.connect(self.on_zoom_changed)
        zoom_layout.addWidget(self.zoom_slider)
        
        self.zoom_label = QLabel("100%")
        self.zoom_label.setMinimumWidth(50)
        zoom_layout.addWidget(self.zoom_label)
        
        self.fit_btn = QPushButton("Fit")
        self.fit_btn.clicked.connect(self.fit_to_window)
        zoom_layout.addWidget(self.fit_btn)
        
        self.reset_btn = QPushButton("Reset Selection")
        self.reset_btn.clicked.connect(self.crop_label.reset_selection)
        zoom_layout.addWidget(self.reset_btn)
        
        layout.addLayout(zoom_layout)
        
        # Info area
        info_layout = QHBoxLayout()
        
        self.size_label = QLabel("Original: -- x --")
        info_layout.addWidget(self.size_label)
        
        self.crop_size_label = QLabel("Crop: -- x --")
        info_layout.addWidget(self.crop_size_label)
        
        info_layout.addStretch()
        
        layout.addLayout(info_layout)
        
        # Dialog buttons
        btn_layout = QHBoxLayout()
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(self.cancel_btn)
        
        btn_layout.addStretch()
        
        self.apply_btn = QPushButton("Apply Crop")
        self.apply_btn.clicked.connect(self.apply_crop)
        self.apply_btn.setStyleSheet("""
            QPushButton {
                background-color: #e94560;
                color: white;
                font-weight: bold;
                padding: 10px 24px;
            }
        """)
        btn_layout.addWidget(self.apply_btn)
        
        layout.addLayout(btn_layout)
    
    def load_image(self):
        """Load the image for editing."""
        self.original_image = Image.open(self.image_path)
        self.update_display()
        
        w, h = self.original_image.size
        self.size_label.setText(f"Original: {w} x {h}")
    
    def update_display(self):
        """Update the displayed image."""
        if not self.original_image:
            return
        
        # Apply rotation
        img = self.original_image
        if self.current_rotation != 0:
            img = img.rotate(-self.current_rotation, expand=True)
        
        # Convert to QPixmap
        if img.mode == "RGBA":
            qim = QImage(
                img.tobytes("raw", "RGBA"),
                img.width, img.height,
                QImage.Format_RGBA8888
            )
        else:
            img = img.convert("RGB")
            qim = QImage(
                img.tobytes("raw", "RGB"),
                img.width, img.height,
                QImage.Format_RGB888
            )
        
        pixmap = QPixmap.fromImage(qim)
        
        # Apply zoom
        zoom = self.zoom_slider.value() / 100
        self.crop_label.set_image(pixmap, zoom)
    
    def rotate(self, degrees: int):
        """Rotate the image."""
        self.current_rotation = (self.current_rotation + degrees) % 360
        self.crop_label.reset_selection()
        self.update_display()
    
    def flip(self, direction: str):
        """Flip the image."""
        if direction == "horizontal":
            self.original_image = self.original_image.transpose(Image.FLIP_LEFT_RIGHT)
        else:
            self.original_image = self.original_image.transpose(Image.FLIP_TOP_BOTTOM)
        
        self.crop_label.reset_selection()
        self.update_display()
    
    def on_zoom_changed(self, value: int):
        """Handle zoom slider change."""
        self.zoom_label.setText(f"{value}%")
        self.update_display()
    
    def fit_to_window(self):
        """Fit image to window."""
        if not self.original_image:
            return
        
        # Calculate fit zoom
        parent_size = self.crop_label.parent().size()
        img_size = self.original_image.size
        
        zoom_w = (parent_size.width() - 40) / img_size[0] * 100
        zoom_h = (parent_size.height() - 40) / img_size[1] * 100
        
        fit_zoom = min(zoom_w, zoom_h, 100)
        
        self.zoom_slider.setValue(int(fit_zoom))
    
    def on_aspect_changed(self, index: int):
        """Handle aspect ratio selection."""
        # TODO: Implement aspect ratio constraints
        pass
    
    def toggle_grid(self, state: int):
        """Toggle grid overlay."""
        self.crop_label.show_grid = state == Qt.Checked
        self.crop_label.update()
    
    def change_grid_type(self, index: int):
        """Change grid overlay type."""
        types = ["rule_of_thirds", "grid"]
        self.crop_label.grid_type = types[index]
        self.crop_label.update()
    
    def apply_crop(self):
        """Apply the crop and save."""
        crop_rect = self.crop_label.get_crop_rect_original()
        
        if not crop_rect.isValid() or crop_rect.isEmpty():
            # No crop selected - just save with rotation
            img = self.original_image
            if self.current_rotation != 0:
                img = img.rotate(-self.current_rotation, expand=True)
        else:
            # Apply rotation first
            img = self.original_image
            if self.current_rotation != 0:
                img = img.rotate(-self.current_rotation, expand=True)
            
            # Then crop
            box = (
                max(0, crop_rect.x()),
                max(0, crop_rect.y()),
                min(img.width, crop_rect.x() + crop_rect.width()),
                min(img.height, crop_rect.y() + crop_rect.height())
            )
            img = img.crop(box)
        
        # Save to processed folder
        output_dir = self.image_path.parent / "processed"
        output_dir.mkdir(exist_ok=True)
        
        self.output_path = output_dir / f"{self.image_path.stem}-cropped.webp"
        
        # Convert to RGB if needed
        if img.mode in ("RGBA", "P"):
            background = Image.new("RGB", img.size, (255, 255, 255))
            if img.mode == "P":
                img = img.convert("RGBA")
            if img.mode == "RGBA":
                background.paste(img, mask=img.split()[-1])
            img = background
        
        img.save(self.output_path, format="WEBP", quality=90)
        
        self.accept()
    
    def get_cropped_path(self) -> Optional[str]:
        """Get the path to the cropped image."""
        return str(self.output_path) if self.output_path else None
