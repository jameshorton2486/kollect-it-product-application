﻿# Sample Outline
