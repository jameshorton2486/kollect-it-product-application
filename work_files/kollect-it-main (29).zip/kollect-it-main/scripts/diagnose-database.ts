#!/usr/bin/env bun
/**
 * Comprehensive Database Diagnosis Script
 * Identifies network, authentication, and configuration issues
 */

console.log('🔍 COMPREHENSIVE DATABASE DIAGNOSIS')
console.log('=====================================\n')

// 1. Environment Variable Check
console.log('📋 STEP 1: Environment Variables')
console.log('-------------------------------')

const dbUrl = process.env.DATABASE_URL
const directUrl = process.env.DIRECT_URL
const resendKey = process.env.RESEND_API_KEY

console.log(`DATABASE_URL: ${dbUrl ? '✓ Set' : '❌ Missing'}`)
console.log(`DIRECT_URL: ${directUrl ? '✓ Set' : '❌ Missing'}`)
console.log(`RESEND_API_KEY: ${resendKey ? '✓ Set' : '❌ Missing'}`)

if (!dbUrl) {
  console.log('\n❌ CRITICAL: DATABASE_URL is not set!')
  console.log('Please add it to .env.local')
  process.exit(1)
}

// 2. Connection String Analysis
console.log('\n🔗 STEP 2: Connection String Analysis')
console.log('------------------------------------')

const urlPattern = /^postgresql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/([^?]+)(\?.+)?$/
const urlParts = dbUrl.match(urlPattern)

if (urlParts) {
  const [, user, , host, port, database, params] = urlParts // Removed 'password'

  console.log(
    `Protocol: ${dbUrl.startsWith('postgresql://') ? '✓ postgresql://' : '⚠️  postgres:// (should be postgresql://)'}`
  )
  console.log(`User: ${user}`)
  console.log(`Host: ${host}`)
  console.log(
    `Port: ${port} ${
      port === '6543'
        ? '(✓ Pooler)'
        : port === '5432'
        ? '(⚠️  Direct)'
        : '(❌ Invalid)'
    }`
  )
  console.log(`Database: ${database}`)
  console.log(`Params: ${params || 'None'}`)

  // Check required parameters
  const hasPooler = params?.includes('pgbouncer=true')
  console.log(`pgbouncer=true: ${hasPooler ? '✓ Present' : '❌ Missing'}`)
} else {
  console.log('❌ Invalid DATABASE_URL format!')
  console.log('Expected: postgresql://user:pass@host:port/db?params')
  process.exit(1)
}

// 3. Network Connectivity Test
console.log('\n🌐 STEP 3: Network Connectivity')
console.log('------------------------------')

const { execSync } = require('child_process')

try {
  // Extract host from URL
  const host = urlParts[3]

  console.log(`Testing connection to ${host}:6543...`)

  // Try to resolve DNS first
  try {
    execSync(`nslookup ${host}`, {
      encoding: 'utf-8',
      timeout: 5000,
    }); // Removed 'dnsResult'
    console.log('✓ DNS resolution successful')
  } catch {
    console.log('❌ DNS resolution failed')
  }

  // Test if we can reach the host at all
  try {
    execSync(`ping -n 1 -w 1000 ${host}`, {
      encoding: 'utf-8',
      timeout: 5000,
    }); // Removed 'pingResult'
    console.log('✓ Host is reachable')
  } catch {
    console.log('⚠️  Host ping failed')
  }
} catch (error) {
  if (error instanceof Error) {
    console.log('⚠️  Network test failed:', error.message)
  } else {
    console.log('⚠️  Network test failed:', String(error))
  }
}

// 4. Supabase Project Status Check
console.log('\n📡 STEP 4: Supabase Project Status')
console.log('----------------------------------')

const projectRef = urlParts[3].split('.')[1] // Extract project reference
console.log(`Project Reference: ${projectRef}`)
console.log(`Supabase URL: https://supabase.com/dashboard/project/${projectRef}`)

console.log('\n💡 Manual Checks Required:')
console.log('1. Visit the Supabase dashboard URL above')
console.log('2. Check if the project shows as "Active" (not "Paused")')
console.log('3. Go to Settings → Database to verify connection details')
console.log('4. If paused, click "Resume" to reactivate')

// 5. Alternative Connection Test
console.log('\n🔌 STEP 5: Database Connection Test')
console.log('----------------------------------')

console.log('Testing Prisma connection...')

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient({
  log: ['error'],
  datasources: {
    db: {
      url: dbUrl
    }
  }
})

try {
  await prisma.$connect()
  console.log('✅ Prisma connection successful!')

  // Test basic query
  try {
    const result = await prisma.$queryRaw`SELECT NOW() as current_time`;
    if (Array.isArray(result) && result.length > 0 && 'current_time' in result[0]) {
      console.log('✅ Database query successful!')
      console.log('Current database time:', result[0].current_time)

    } else {
      console.log('⚠️  Unexpected query result format:', result)
    }
  } catch (error) {
    if (error instanceof Error) {
      console.log('❌ Database connection failed!')
      console.log('Error:', error.message)

      if (error.message.includes('SASL authentication failed')) {
        console.log('🔧 AUTHENTICATION ISSUE DETECTED')
      } else if (error.message.includes('Can\'t reach database server')) {
        console.log('🔧 CONNECTIVITY ISSUE DETECTED')
      } else if (error.message.includes('timeout')) {
        console.log('🔧 TIMEOUT ISSUE DETECTED')
      }
    } else {
      console.log('❌ Database connection failed with unknown error:', String(error))
    }
  }

} catch (error) {
  const message = error instanceof Error ? error.message : String(error)

  console.log('❌ Database connection failed!')
  console.log('Error:', message)

  // Provide specific guidance based on error
  if (message.includes('SASL authentication failed')) {
    console.log('\n🔧 AUTHENTICATION ISSUE DETECTED')
    console.log('Possible causes:')
    console.log('- Incorrect password in DATABASE_URL')
    console.log('- Database user permissions changed')
    console.log('- Supabase project credentials rotated')
    console.log('\nSolution: Get fresh connection string from Supabase Dashboard')
  } else if (message.includes('Can\'t reach database server')) {
    console.log('\n🔧 CONNECTIVITY ISSUE DETECTED')
    console.log('Possible causes:')
    console.log('- Supabase project is paused')
    console.log('- Network connectivity issues')
    console.log('- Supabase maintenance')
    console.log('\nSolution: Check Supabase dashboard and ensure project is active')
  } else if (message.includes('timeout')) {
    console.log('\n🔧 TIMEOUT ISSUE DETECTED')
    console.log('Possible causes:')
    console.log('- Slow network connection')
    console.log('- Server overload')
    console.log('\nSolution: Try again in a few minutes')
  }

} finally {
  await prisma.$disconnect()
}

console.log('\n📋 DIAGNOSIS COMPLETE')
console.log('====================')
console.log('Review the results above to identify the root cause.')
console.log('Most common issue: Supabase project is paused - check dashboard!')