import { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductGrid from "@/components/ProductGrid";
import { prisma } from "@/lib/prisma";

interface CategoryPageProps {
  params: Promise<{ slug: string }>;
}

export const revalidate = 60;

async function getCategoryData(slug: string) {
  return prisma.category.findUnique({
    where: { slug },
    include: {
      subcategories: {
        orderBy: { name: "asc" },
      },
      products: {
        where: { 
          status: "active",
          isDraft: false,
        },
        include: {
          images: { orderBy: { order: "asc" }, take: 1 },
          category: true,
          subcategory: true,
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });
}

export async function generateMetadata(
  props: CategoryPageProps,
): Promise<Metadata> {
  const { params } = props;
  const { slug } = await params;
  const category = await prisma.category.findUnique({
    where: { slug },
  });

  if (!category) {
    return {
      title: "Category Not Found – Kollect-It",
      description: "The requested collection could not be found.",
    };
  }

  const description = category.description ||
    `Browse authenticated ${category.name.toLowerCase()} at Kollect-It. Carefully curated and quality-reviewed pieces.`;

  return {
    title: `${category.name} | Kollect-It`,
    description,
    alternates: {
      canonical: `https://kollect-it.com/category/${category.slug}`,
    },
    openGraph: {
      title: `${category.name} | Kollect-It`,
      description,
      url: `https://kollect-it.com/category/${category.slug}`,
      type: "website",
    },
    twitter: {
      card: "summary",
      title: `${category.name} | Kollect-It`,
      description,
    },
  };
}

export default async function CategoryPage(props: CategoryPageProps) {
  const { params } = props;
  const { slug } = await params;
  const category = await getCategoryData(slug);

  if (!category) {
    notFound();
  }

  const products = category.products;

  return (
    <main className="bg-lux-pearl text-ink-900">
      <section className="bg-lux-cream section-normal">
        <div className="container mx-auto max-w-4xl">
          <Link
            href="/categories"
            className="text-label text-lux-gold mb-4 inline-block hover:text-lux-gold-light transition-colors"
          >
            ← Back to all categories
          </Link>

          <div className="space-y-4">
            <p className="text-label text-lux-gold mb-2">Category</p>
            <h1 className="heading-page text-lux-black">
              {category.name}
            </h1>
            <p className="lead max-w-2xl">
              {category.description ||
                "A carefully selected collection of pieces in this category, each one chosen for its quality, character, or story."}
            </p>
          </div>
        </div>
      </section>

      {/* Subcategories Section */}
      {category.subcategories && category.subcategories.length > 0 && (
        <section className="bg-lux-pearl section-normal">
          <div className="container mx-auto max-w-4xl">
            <h2 className="heading-section text-lux-black mb-6">
              Browse by Subcategory
            </h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {category.subcategories.map((sub) => {
                const subProductCount = products.filter(
                  (p) => p.subcategoryId === sub.id
                ).length;
                return (
                  <Link
                    key={sub.id}
                    href={`/subcategory/${sub.slug}`}
                    className="group border border-lux-silver-soft bg-lux-white p-4 rounded-lg hover:border-lux-gold hover:shadow-soft transition-all"
                  >
                    <div className="heading-subsection text-lux-black group-hover:text-lux-gold transition-colors">
                      {sub.name}
                    </div>
                    {subProductCount > 0 && (
                      <div className="text-muted mt-1">
                        {subProductCount} {subProductCount === 1 ? "item" : "items"}
                      </div>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      )}

      <section className="bg-lux-pearl section-normal">
        <div className="container mx-auto max-w-4xl">
          {products.length > 0 ? (
            <>
              <div className="mb-10 space-y-2">
                <h2 className="heading-section text-lux-black">
                  All {category.name} Pieces
                </h2>
                <p className="text-muted">
                  {products.length === 1
                    ? "One piece currently available in this category."
                    : `${products.length} pieces currently available in this category.`}
                </p>
              </div>
              <ProductGrid products={products} />
            </>
          ) : (
            <div className="rounded-2xl border border-dashed border-lux-silver-soft bg-lux-cream px-6 py-12 text-center">
              <p className="heading-subsection text-lux-black mb-2">
                No pieces available in this category right now
              </p>
              <p className="text-muted max-w-2xl mx-auto">
                I&apos;m always adding new pieces to the collection. Check back soon, or{" "}
                <Link
                  href="/contact"
                  className="text-lux-gold underline-offset-4 hover:underline font-medium"
                >
                  let me know
                </Link>{" "}
                what you&apos;re looking for and I&apos;ll keep an eye out for similar pieces.
              </p>
              <div className="mt-6">
                <Link
                  href="/browse"
                  className="btn-secondary rounded-full"
                >
                  Browse all categories
                </Link>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
