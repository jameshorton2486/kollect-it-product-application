import { redirect } from 'next/navigation';

export default function SellPage() {
  redirect('/consign');
}
