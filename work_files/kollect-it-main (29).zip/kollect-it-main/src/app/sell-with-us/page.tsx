import { redirect } from 'next/navigation';

export default function SellWithUsPage() {
  redirect('/consign');
}
