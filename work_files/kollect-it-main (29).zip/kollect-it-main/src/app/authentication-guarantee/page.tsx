import { redirect } from 'next/navigation';

export default function AuthenticationGuaranteePage() {
  redirect('/authentication');
}

